use shttrdb

TITLE="Software"
export TITLE
PAGE_ID=3
export PAGE_ID

. ${SHTTR_APP}/models/${CONTROLLER}

. ${SHTTR_APP}/views/${CONTROLLER}
