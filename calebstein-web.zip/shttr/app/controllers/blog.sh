TITLE="Blog"
export TITLE
PAGE_ID=4
export PAGE_ID

. ${SHTTR_APP}/models/${CONTROLLER}

. ${SHTTR_APP}/views/${CONTROLLER}
