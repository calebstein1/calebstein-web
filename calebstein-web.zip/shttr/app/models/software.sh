read_each from software
