read_each from blog_posts
