use esh

v shared/app.html
v shared/nav.html
vf shared/x_server.html
v index.html
v shared/btm.html
