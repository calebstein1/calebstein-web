use esh

v shared/app.html
v shared/nav.html
vf shared/x_server.html

echo '<div class="container p-4 text-center" data-turn-enter data-turn-exit>'
  v index.html
echo '</div>'

v shared/btm.html
