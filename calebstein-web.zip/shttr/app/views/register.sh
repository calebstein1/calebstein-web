use esh

v shared/app.html
v register/index.html
v shared/btm.html
