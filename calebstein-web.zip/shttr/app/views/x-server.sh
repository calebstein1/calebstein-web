use esh

v shared/app.html
v shared/nav.html
v index.html
v shared/btm.html
