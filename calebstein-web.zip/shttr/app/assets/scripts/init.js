let colorScheme;
let curPage;
let prevPage;
let nextPage;
let viaScroll = false;
let viaSwipe = false;
